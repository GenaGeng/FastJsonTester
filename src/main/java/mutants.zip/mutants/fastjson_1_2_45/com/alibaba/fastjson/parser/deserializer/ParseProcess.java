package mutants.fastjson_1_2_45.com.alibaba.fastjson.parser.deserializer;


public interface ParseProcess {

}
