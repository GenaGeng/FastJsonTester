package mutants.fastjson_1_2_45.com.alibaba.fastjson.serializer;


public interface SerializeFilter {

}
