package mutants.fastjson_1_2_32.com.alibaba.fastjson.parser.deserializer;


public interface ParseProcess {

}
