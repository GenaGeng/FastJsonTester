package mutants.fastjson_1_2_48.com.alibaba.fastjson.parser.deserializer;


public interface ParseProcess {

}
