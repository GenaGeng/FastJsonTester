package mutants.fastjson_1_2_48.com.alibaba.fastjson.serializer;


public interface SerializeFilter {

}
